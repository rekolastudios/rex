I am not the author, the video list is a hardcoded response

https://ytch.xyz/

mirror https://stevemk14ebr.github.io/YTCH/
